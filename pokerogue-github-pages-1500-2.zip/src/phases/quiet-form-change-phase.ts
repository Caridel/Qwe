import { applyOnLoseAbAttrs, applyPostFormChangeAbAttrs } from "#abilities/apply-ab-attrs";
import { audioManager } from "#app/global-audio-manager";
import { globalScene } from "#app/global-scene";
import { getPokemonNameWithAffix } from "#app/messages";
import { getSpeciesFormChangeMessage } from "#data/form-change-triggers";
import type { SpeciesFormChange } from "#data/pokemon-forms";
import { getTypeRgb } from "#data/type";
import { BattlerTagType } from "#enums/battler-tag-type";
import type { Pokemon } from "#field/pokemon";
import { BattlePhase } from "#phases/battle-phase";
import { playTween } from "#utils/anim-utils";

/**
 * Phase handling mid-battle form changes that do not occur in the Party modal
 * and do not show an evolution dialogue.
 */
// TODO: Rename as the term "quiet" can be confusing
export class QuietFormChangePhase extends BattlePhase {
  public readonly phaseName = "QuietFormChangePhase";

  public readonly pokemon: Pokemon;
  protected readonly formChange: SpeciesFormChange;
  /** The Pokemon's prior name before changing forms. */
  // TODO: remove? it's unused
  private preName: string;

  constructor(pokemon: Pokemon, formChange: SpeciesFormChange) {
    super();

    this.pokemon = pokemon;
    this.formChange = formChange;
  }

  async start(): Promise<void> {
    super.start();

    this.preName = getPokemonNameWithAffix(this.pokemon);

    // Don't do anything if the user is already in the same form.
    if (this.pokemon.formIndex === this.pokemon.species.forms.findIndex(f => f.formKey === this.formChange.formKey)) {
      super.end();
      return;
    }

    if (!this.pokemon.visible) {
      await this.checkInactive();
      return;
    }

    if (this.pokemon.isActive(true)) {
      await this.playFormChangeTween();
    } else {
      // End early if an enemy pokemon is fainted to avoid animation softlocks
      // TODO: Might be better to avoid triggering the form change altogether...
      if (this.pokemon.isFainted() && !this.pokemon.isPlayer()) {
        super.end();
        return;
      }
      await this.doChangeForm();
      this.showFormChangeTextAndEnd();
    }
  }

  /**
   * Helper function to show text upon changing forms and end the phase.
   * @remarks
   * Does not actually change the user's form.
   */
  private showFormChangeTextAndEnd(): void {
    const { pokemon, formChange, preName } = this;
    const { ui } = globalScene;
    ui.showText(getSpeciesFormChangeMessage(pokemon, formChange, preName), null, () => this.end(), 1500);
  }

  /**
   * Handle queueing messages for form changing a currently invisible player Pokemon.
   */
  private async checkInactive(): Promise<void> {
    // End immediately for off-field enemy pokemon
    // TODO: This avoids actually doing the form change, is this intended?
    if (!this.pokemon.isPlayer() && !this.pokemon.isActive(true)) {
      super.end();
      return;
    }

    await this.doChangeForm();
    this.showFormChangeTextAndEnd();
  }

  /**
   * Wrapper function to queue effects related to a Pokemon changing forms.
   */
  private async doChangeForm(): Promise<void> {
    const { pokemon, formChange } = this;

    // TODO: This will have ordering issues with on lose abilities' trigger messages showing after this Phase ends
    // if any are given to a Pokemon with mid-battle form changes.
    // If this is desired later on, the animation/textual part of `QuietFormChangePhase` will need to be pulled out
    // into a separate Phase, though I doubt balence team will want to do this for a while...

    applyOnLoseAbAttrs({ pokemon });
    await pokemon.changeForm(formChange);
    if (pokemon.isActive(true)) {
      applyPostFormChangeAbAttrs({ pokemon });
    }
  }

  private async playFormChangeTween(): Promise<void> {
    const [pokemonTintSprite, pokemonFormTintSprite] = [this.getPokemonSprite(), this.getPokemonSprite()];

    // TODO: This is never deregistered
    this.pokemon.getSprite().on("animationupdate", (_anim, frame) => {
      if (frame.textureKey === pokemonTintSprite.texture.key) {
        pokemonTintSprite.setFrame(frame.textureFrame);
      } else {
        pokemonFormTintSprite.setFrame(frame.textureFrame);
      }
    });

    pokemonTintSprite // formatting
      .setAlpha(0)
      .setTintFill(0xffffff);
    pokemonFormTintSprite // formatting
      .setVisible(false)
      .setTintFill(0xffffff);

    audioManager.playSound("battle_anims/PRSFX- Transform");

    await playTween({
      targets: pokemonTintSprite,
      alpha: 1,
      duration: 1000,
      ease: "Cubic.easeIn",
    });

    this.pokemon.setVisible(false);
    await this.doChangeForm();

    pokemonFormTintSprite.setScale(0.01);
    const spriteKey = this.pokemon.getBattleSpriteKey();
    // TODO: Why do we play and then immediately stop the form tint sprite?
    // The thing isn't even visible anyways at this point in the code
    pokemonFormTintSprite.play(spriteKey).stop();

    pokemonFormTintSprite.setVisible(true);
    globalScene.tweens.add({
      targets: pokemonTintSprite,
      delay: 250,
      scale: 0.01,
      ease: "Cubic.easeInOut",
      duration: 500,
      onComplete: () => pokemonTintSprite.destroy(),
    });
    await playTween({
      targets: pokemonFormTintSprite,
      delay: 250,
      scale: this.pokemon.getSpriteScale(),
      ease: "Cubic.easeInOut",
      duration: 500,
    });

    this.pokemon.setVisible(true);
    await playTween({
      targets: pokemonFormTintSprite,
      delay: 250,
      alpha: 0,
      ease: "Cubic.easeOut",
      duration: 1000,
    });
    pokemonTintSprite.setVisible(false);

    this.showFormChangeTextAndEnd();
  }

  private getPokemonSprite(): Phaser.GameObjects.Sprite {
    const sprite = globalScene.addPokemonSprite(
      this.pokemon,
      this.pokemon.x + this.pokemon.getSprite().x,
      this.pokemon.y + this.pokemon.getSprite().y,
      "pkmn__sub",
    );
    sprite.setOrigin(0.5, 1);
    const spriteKey = this.pokemon.getBattleSpriteKey();
    sprite.play(spriteKey).stop();
    sprite.setPipeline(globalScene.spritePipeline, {
      tone: [0.0, 0.0, 0.0, 0.0],
      hasShadow: false,
      teraColor: getTypeRgb(this.pokemon.getTeraType()),
      isTerastallized: this.pokemon.isTerastallized,
    });
    ["spriteColors", "fusionSpriteColors"].forEach(k => {
      if (this.pokemon.summonData.speciesForm) {
        k += "Base";
      }
      sprite.pipelineData[k] = this.pokemon.getSprite().pipelineData[k];
    });
    globalScene.field.add(sprite);
    return sprite;
  }

  public override end(): void {
    const { pokemon } = this;

    // Autotomize's weight reduction is reset when form changing
    pokemon.removeTag(BattlerTagType.AUTOTOMIZED);

    // TODO: This eternatus boss fight code should almost certainly go in its own subclass phase
    if (globalScene.currentBattle.isClassicFinalBoss && pokemon.isEnemy()) {
      audioManager.playBgm();
      globalScene.phaseManager.unshiftNew(
        "PokemonHealPhase", //
        pokemon.getBattlerIndex(),
        pokemon.getMaxHp(),
        { showFullHpMessage: false, healStatus: true, fullRestorePP: true },
      );
      // TODO: Use or create a helper function to remove all tags on a Pokemon
      pokemon.findAndRemoveTags(() => true);
      pokemon.bossSegments = 5;
      pokemon.bossSegmentIndex = 4;
      pokemon.initBattleInfo();
      pokemon.cry();

      globalScene.phaseManager.cancelMove(p => p.pokemon === pokemon);
    }

    super.end();
  }
}
