import { globalScene } from "#app/global-scene";
import { getPokemonNameWithAffix } from "#app/messages";
import { CommonBattleAnim } from "#data/battle-anims";
import { SpeciesFormChangeTeraTrigger } from "#data/form-change-triggers";
import { CommonAnim } from "#enums/move-anims-common";
import { PokemonType } from "#enums/pokemon-type";
import type { Pokemon } from "#field/pokemon";
import { BattlePhase } from "#phases/battle-phase";
import { achvs } from "#system/achv";
import { getPokemonTypeLocaleKey } from "#utils/i18n";
import i18next from "i18next";

export class TeraPhase extends BattlePhase {
  public readonly phaseName = "TeraPhase";
  public readonly pokemon: Pokemon;

  constructor(pokemon: Pokemon) {
    super();

    this.pokemon = pokemon;
  }

  start() {
    super.start();

    globalScene.phaseManager.queueMessage(
      i18next.t("battle:pokemonTerastallized", {
        pokemonNameWithAffix: getPokemonNameWithAffix(this.pokemon),
        type: i18next.t(getPokemonTypeLocaleKey(this.pokemon.getTeraType())),
      }),
    );

    new CommonBattleAnim(CommonAnim.TERASTALLIZE, this.pokemon).play(false, () => {
      this.end();
    });
  }

  end() {
    this.pokemon.isTerastallized = true;
    // Remove added type from Forest's Curse/Trick-or-Treat
    this.pokemon.summonData.addedType = null;
    this.pokemon.updateSpritePipelineData();

    globalScene.triggerPokemonFormChange(this.pokemon, SpeciesFormChangeTeraTrigger);

    if (this.pokemon.isPlayer()) {
      globalScene.arena.playerTerasUsed += 1;
      globalScene.validateAchv(achvs.TERASTALLIZE);
      if (this.pokemon.getTeraType() === PokemonType.STELLAR) {
        globalScene.validateAchv(achvs.STELLAR_TERASTALLIZE);
      }
    }

    super.end();
  }
}
