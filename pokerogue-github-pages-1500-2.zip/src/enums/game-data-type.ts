/**
 * enum for the game data types
 */
export enum GameDataType {
  SYSTEM,
  SESSION,
  SETTINGS,
  TUTORIALS,
  SEEN_DIALOGUES,
  RUN_HISTORY,
  MAPPING_CONFIG,
}
