# GitHub Pages 게임 실행

1. 이 폴더의 내용을 GitHub 저장소의 `main` 브랜치에 올립니다.
2. 저장소 Settings → Pages → Source에서 **GitHub Actions**를 선택합니다.
3. Actions의 `Deploy game to GitHub Pages`가 완료될 때까지 기다립니다.
4. Pages에 표시된 주소를 브라우저에서 열면 게임이 실행됩니다.

이 빌드는 개발 모드이며, 개발 모드에서만 일반 뽑기권이 1,500개로 시드됩니다. 기존 저장 데이터를 불러와도 개발 모드에서는 일반 뽑기권이 1,500개로 맞춰집니다.
